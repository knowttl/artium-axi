Artium frame and chrome extraction, 96 before/after screenshot pairs.

Baseline: 64bba2600f9f421d22d67cc445e9cc05582d897d
Candidate: 75b1215a27ce17ea7246b9adfad5252402f0d339 with the frame CSS review fixes.
Baseline CSS SHA-256: b83b2a0cc6c620d7ad3a95bad2e9d54047cca26a461abecaaf3aa5d44b7c495b
Candidate CSS SHA-256: 2ff80c82f222b0b3f2372970513000a770c540a5894095c99a9ad6093f8bde57

Both sides use the same running synthetic fixture and Chromium session.
Before replaces the style.css response with the base revision token and component CSS.
After loads the stylesheet served by the corrected candidate.
Matches use the same routes, viewport, system color scheme and open/closed menu state.
All 96 pairs were compared as decoded RGBA pixels.
