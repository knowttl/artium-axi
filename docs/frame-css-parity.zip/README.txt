Artium frame and chrome extraction, 96 before/after screenshot pairs.

Baseline: 64bba2600f9f421d22d67cc445e9cc05582d897d
Candidate: 8df3a8d80415bf91ec56b5c8e13fad961b0bdfcc with the Astryx token review fixes.
Baseline CSS SHA-256: b83b2a0cc6c620d7ad3a95bad2e9d54047cca26a461abecaaf3aa5d44b7c495b
Candidate CSS SHA-256: 1beb683957131b5cf29f5753f670def33cd81f36c39526acb2f8309891442a11

Both sides use the same synthetic fixture and Chromium session.
Before fulfills the stylesheet request with the base revision token and component CSS.
After captures the live stylesheet served by the corrected candidate.
Computed font weights, border widths and spacing resets matched at default and 20px root font sizes for all 96 cases.
The 96 pairs were also compared as decoded RGBA pixels at the default root font size.
