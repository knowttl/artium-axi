Artium card and layout CSS parity, 130 before-and-after screenshot pairs.

All pairs are byte-identical PNGs.
Each pair uses the baseline stylesheet listed below for its before capture.
The capture sets identify the candidate stylesheet for each after image.

Baseline revision: d61c6f773abf3b612c8d7ae11548677a2cee8a74
Baseline CSS SHA-256: 24e0fca2c7604310c9348dfad6e560a69d4cbb3403a6ee5010c2c95745bf12d1
Final candidate CSS SHA-256: 69820b8f07f1992cf15c658043248d57fdbd761946e86ec5080b138596a098b6
Prior candidate CSS SHA-256: 793ef2e5f9e053018abde1a89098cc93c9750e1102b157e1522fa687c8624ba2
Historical candidate CSS SHA-256: b2b06483e586b68337405774690984a4736a33bc9b8e4fd1ffb5e268f58328ee

Final capture set (12 pairs)

The local browser fixture rendered the live Falcon Advanced tab in Chrome with the saved settings, a valid JSON object and malformed JSON.
The typed cases use the actual settings control and show the resulting validation notes.
The note colors, computed styles and layout rectangles match the baseline.
Each state was captured in light and dark at 1280 by 800 and 390 by 844.
For each before image, the baseline stylesheet rules occupied the original cascade position in the same document.

dark-1280-state-tool-json-invalid.png
dark-1280-state-tool-json-valid.png
dark-1280-tool-advanced.png
dark-390-state-tool-json-invalid.png
dark-390-state-tool-json-valid.png
dark-390-tool-advanced.png
light-1280-state-tool-json-invalid.png
light-1280-state-tool-json-valid.png
light-1280-tool-advanced.png
light-390-state-tool-json-invalid.png
light-390-state-tool-json-valid.png
light-390-tool-advanced.png

Prior capture set (86 pairs)

The pairs below use the candidate stylesheet from revision d94bbbe1053e9a53ce35dedfd85e5487933002d4.
They cover Person, Role, Account, tool and instance pages, audit and SSH disclosures, and the provider and invitation pages.
The Role status variant simulates tool health states, including Checking with an info dot.
The other states use the rendered pages and controls.
Each state was captured in light and dark at 1280 by 800 and 390 by 844, with an extra 900 by 800 capture of Person in each theme.
Computed styles and layout rectangles matched the baseline.

dark-1280-account-saving-open.png
dark-1280-account.png
dark-1280-instance.png
dark-1280-invitations-provider.png
dark-1280-invsheet.png
dark-1280-person.png
dark-1280-provider-setup.png
dark-1280-record-open.png
dark-1280-record.png
dark-1280-role.png
dark-1280-signin-provider.png
dark-1280-ssh-audit-open.png
dark-1280-ssh-credentials-password.png
dark-1280-ssh-host-open.png
dark-1280-ssh.png
dark-1280-sshaudit.png
dark-1280-sshcreds.png
dark-1280-state-role-dots.png
dark-1280-tool-access.png
dark-1280-tool.png
dark-1280-toolwrites.png
dark-390-account-saving-open.png
dark-390-account.png
dark-390-instance.png
dark-390-invitations-provider.png
dark-390-invsheet.png
dark-390-person.png
dark-390-provider-setup.png
dark-390-record-open.png
dark-390-record.png
dark-390-role.png
dark-390-signin-provider.png
dark-390-ssh-audit-open.png
dark-390-ssh-credentials-password.png
dark-390-ssh-host-open.png
dark-390-ssh.png
dark-390-sshaudit.png
dark-390-sshcreds.png
dark-390-state-role-dots.png
dark-390-tool-access.png
dark-390-tool.png
dark-390-toolwrites.png
dark-900-person.png
light-1280-account-saving-open.png
light-1280-account.png
light-1280-instance.png
light-1280-invitations-provider.png
light-1280-invsheet.png
light-1280-person.png
light-1280-provider-setup.png
light-1280-record-open.png
light-1280-record.png
light-1280-role.png
light-1280-signin-provider.png
light-1280-ssh-audit-open.png
light-1280-ssh-credentials-password.png
light-1280-ssh-host-open.png
light-1280-ssh.png
light-1280-sshaudit.png
light-1280-sshcreds.png
light-1280-state-role-dots.png
light-1280-tool-access.png
light-1280-tool.png
light-1280-toolwrites.png
light-390-account-saving-open.png
light-390-account.png
light-390-instance.png
light-390-invitations-provider.png
light-390-invsheet.png
light-390-person.png
light-390-provider-setup.png
light-390-record-open.png
light-390-record.png
light-390-role.png
light-390-signin-provider.png
light-390-ssh-audit-open.png
light-390-ssh-credentials-password.png
light-390-ssh-host-open.png
light-390-ssh.png
light-390-sshaudit.png
light-390-sshcreds.png
light-390-state-role-dots.png
light-390-tool-access.png
light-390-tool.png
light-390-toolwrites.png
light-900-person.png

Historical capture set (32 pairs)

The remaining pairs use the initial extraction from revision 2310aa73f8cc63d5aedd16813738a3b512dbc7b6.
They cover other card and layout pages and supplemental simulated states.
Counts by state follow.

audit (4), roles (4), sheet (4), state-record-sections (4), state-ssh-executions (4), state-tool-setup-fail (4), tools (4), users (4).
