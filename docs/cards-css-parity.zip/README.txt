Artium card and layout styles extraction, 126 before-and-after screenshot pairs.

All 247 captured pairs are identical as PNG files, so they are also identical as decoded RGBA pixels.
This archive retains 126 of them; the other 121 (the 900px wide and system dark theme captures) are not retained.

Baseline revision: d61c6f773abf3b612c8d7ae11548677a2cee8a74
Baseline CSS SHA-256: 24e0fca2c7604310c9348dfad6e560a69d4cbb3403a6ee5010c2c95745bf12d1
Candidate CSS SHA-256: b2b06483e586b68337405774690984a4736a33bc9b8e4fd1ffb5e268f58328ee

The baseline stylesheet is tokens, components, frame, forms and tables, served as /admin/assets/style.css.
The candidate stylesheet adds cards.css after tables.css, with every card and layout rule moved out of components.ts in its original relative order.
Rules for dialogs, the side sheet, menus, signed-out screens, base elements and global resets stay in components.ts.
So do selectors that no markup in src/views can match: .list-row .grow strong a, .tool-grid .status, .card-body .list-row, .card > form, .card-foot form, .list-row form, .card form, form.card, .card-foot p, .list-row h2, .sheet-head .btn, .copyfield input:not(.input), .all-fields .kv, .status svg.i, .status.warn, .status.neutral, .list-row:last-child, .list-row .btn and .field .hint.

Page screenshots

Both sides use the same synthetic fixture (test/fake-service/browser-auth.mjs) and headless Chrome 154 with a 1x device scale factor.
Chrome runs with --disable-gpu, --disable-lcd-text, --num-raster-threads=1, --disable-threaded-animation, --disable-threaded-scrolling, --disable-checker-imaging, --disable-partial-raster, --run-all-compositor-stages-before-draw and --disable-composited-antialiasing, which made three repeated baseline captures of eight pages byte-identical.
Before is the build of the baseline revision made in a separate source tree and after is the build of the candidate.
The fixture seeds 103 audit records, one SSH execution and the default users, roles and tools.
Time-dependent text, the localhost port in the account commands and the request ID in the audit record sheet are set to fixed values on both sides before capture.
The 21 pages are overview, users, person, roles, role, tools, tool, instance, invitations, signin, tokens, audit, account, an audit record with its docked sheet, SSH hosts, SSH audit, SSH credentials, the tool Write permissions tab, the tool Instances tab, the open Add person sheet and the open New invitation sheet.
They are captured in light, dark and system dark themes at 1280 by 800, 900 by 800 and 390 by 844, giving 189 pairs.
The signed-out sign-in page is captured in light and dark at 1280 and 390, giving 4 more pairs.
The users, roles and audit pages are also captured at 1280 in the light theme with keyboard focus on the first row link and with the pointer over a row, giving 6 more pairs.

State screenshots (files named *-state-*)

The fixture cannot render every state that the card and layout rules style.
For eight states the harness opens the real page and changes its markup to what the views produce in that state, then captures the whole page.
The states are: status dots in every tone beside faint, muted and monospace text (Role); an audit record sheet with Settings changes and Failure diagnostic sections (Audit record); three SSH executions in a row (SSH audit); completed vertical setup steps with a copy field, an open disclosure card and copied status text (Account); a failed and a completed setup step (Tool); a valid and an invalid native settings JSON note (Tool Advanced tab); and a visible form error in the Add person sheet.
Each state is captured in light and dark themes at 1280 by 800, 900 by 800 and 390 by 844, giving 48 pairs.
Of these, the 32 pairs at 1280 and 390 are retained.

Retained pairs

The archive retains the light and dark captures at 1280 and 390: 84 page pairs, 32 state pairs, the 4 sign-in pairs and the 6 focus and hover pairs, 126 in all.

Computed styles

These checks support the screenshots and are not a substitute for them.
292 page states were dumped on each side: the 21 pages and 8 states in light and dark themes at 1280, 900 and 390 widths at the default root font size, and at 1280 and 390 at a 20px root font size, plus the signed-out page.
Each dump hashes the sorted computed property list of every element, with ::before, ::after and ::marker where they generate content.
Across the 292 dumps, 185826 elements matched between baseline and candidate.
All 97 selectors in cards.css match an element on at least one of the captured pages or states.
A deliberate font weight change to the avatar rule in cards.css was detected by both the screenshot comparison and the computed style comparison.
