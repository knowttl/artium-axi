Artium card and layout CSS parity, 168 before-and-after screenshot pairs.

All pairs are byte-identical PNGs. The final and historical capture sets are identified by filename below.

Baseline revision: d61c6f773abf3b612c8d7ae11548677a2cee8a74
Baseline CSS SHA-256: 24e0fca2c7604310c9348dfad6e560a69d4cbb3403a6ee5010c2c95745bf12d1
Final candidate CSS SHA-256: 793ef2e5f9e053018abde1a89098cc93c9750e1102b157e1522fa687c8624ba2
Historical candidate CSS SHA-256: b2b06483e586b68337405774690984a4736a33bc9b8e4fd1ffb5e268f58328ee

Final capture set (94 pairs)

The synthetic browser fixture rendered real pages in local headless Chrome at device scale 1.
The fixture used a synthetic Entra provider, local break-glass administrator, SSH host, audit records and retained SSH execution.
The Role status variant simulates tool health states on the live Role page, including Checking with an info dot.
The other states use the rendered markup and built-in controls.
Account includes its file-saving disclosure, and Audit and SSH include expanded disclosures and both SSH credential methods.
The provider cases include Invitations with a provider available, the populated Sign-in & SSO page, an open New invitation sheet and the provider setup page with the Redirect URI field.
Each state was captured in light and dark at 1280 by 800 and 390 by 844.
Person was also captured at 900 by 800 to exercise the range between the narrow and wide layout breakpoints.
Each after image uses the stylesheet served by the final candidate build.
Each before image uses the baseline stylesheet rules at the original cascade position in the same browser document.
Computed styles and layout rectangles also match across the final pairs.

dark-1280-account-saving-open.png
dark-1280-account.png
dark-1280-instance.png
dark-1280-invitations-provider.png
dark-1280-invsheet.png
dark-1280-person.png
dark-1280-provider-setup.png
dark-1280-record-open.png
dark-1280-record.png
dark-1280-role.png
dark-1280-signin-provider.png
dark-1280-ssh-audit-open.png
dark-1280-ssh-credentials-password.png
dark-1280-ssh-host-open.png
dark-1280-ssh.png
dark-1280-sshaudit.png
dark-1280-sshcreds.png
dark-1280-state-role-dots.png
dark-1280-tool-access.png
dark-1280-tool-advanced.png
dark-1280-tool.png
dark-1280-toolinstances.png
dark-1280-toolwrites.png
dark-390-account-saving-open.png
dark-390-account.png
dark-390-instance.png
dark-390-invitations-provider.png
dark-390-invsheet.png
dark-390-person.png
dark-390-provider-setup.png
dark-390-record-open.png
dark-390-record.png
dark-390-role.png
dark-390-signin-provider.png
dark-390-ssh-audit-open.png
dark-390-ssh-credentials-password.png
dark-390-ssh-host-open.png
dark-390-ssh.png
dark-390-sshaudit.png
dark-390-sshcreds.png
dark-390-state-role-dots.png
dark-390-tool-access.png
dark-390-tool-advanced.png
dark-390-tool.png
dark-390-toolinstances.png
dark-390-toolwrites.png
dark-900-person.png
light-1280-account-saving-open.png
light-1280-account.png
light-1280-instance.png
light-1280-invitations-provider.png
light-1280-invsheet.png
light-1280-person.png
light-1280-provider-setup.png
light-1280-record-open.png
light-1280-record.png
light-1280-role.png
light-1280-signin-provider.png
light-1280-ssh-audit-open.png
light-1280-ssh-credentials-password.png
light-1280-ssh-host-open.png
light-1280-ssh.png
light-1280-sshaudit.png
light-1280-sshcreds.png
light-1280-state-role-dots.png
light-1280-tool-access.png
light-1280-tool-advanced.png
light-1280-tool.png
light-1280-toolinstances.png
light-1280-toolwrites.png
light-390-account-saving-open.png
light-390-account.png
light-390-instance.png
light-390-invitations-provider.png
light-390-invsheet.png
light-390-person.png
light-390-provider-setup.png
light-390-record-open.png
light-390-record.png
light-390-role.png
light-390-signin-provider.png
light-390-ssh-audit-open.png
light-390-ssh-credentials-password.png
light-390-ssh-host-open.png
light-390-ssh.png
light-390-sshaudit.png
light-390-sshcreds.png
light-390-state-role-dots.png
light-390-tool-access.png
light-390-tool-advanced.png
light-390-tool.png
light-390-toolinstances.png
light-390-toolwrites.png
light-900-person.png

Historical capture set (74 pairs)

These retained comparisons use the initial extraction, from revision 2310aa73f8cc63d5aedd16813738a3b512dbc7b6.
They cover other pages, focus and hover, and supplemental simulated states.
Each after image outside the final capture list uses the historical candidate checksum above.
Counts by state follow.

audit (4), audit-focus (1), audit-hover (1), invitations (4), login (4), overview (4), roles (4), roles-focus (1), roles-hover (1), sheet (4), signin (4), state-account-steps (4), state-record-sections (4), state-sheet-message (4), state-ssh-executions (4), state-tool-json-invalid (4), state-tool-json-valid (4), state-tool-setup-fail (4), tokens (4), tools (4), users (4), users-focus (1), users-hover (1).
