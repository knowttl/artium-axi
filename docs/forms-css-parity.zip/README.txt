Artium form controls extraction, 95 before-and-after screenshot pairs.

Baseline: e8ea8b5aa7ad05924025f1e85b0ced0960facc6d
Baseline CSS SHA-256: 1beb683957131b5cf29f5753f670def33cd81f36c39526acb2f8309891442a11
Candidate CSS SHA-256: fdbc50945ab1c35600d04a05eff996b9262d3580d39fa9247279eba8a5a5061e

Both sides use the same synthetic fixture and Chromium session.
Before replaces the page stylesheet with the baseline token, component and frame CSS.
After replaces it with the stylesheet served by the candidate.
All 95 pairs at the default root font size are byte-identical PNG files.
They cover 19 pages, the light, dark and system dark themes, and 1280px and 390px viewports.
Two of the 19 pages show an open confirmation dialog and the open add-instance sheet.

The same 190 cases at the default and 20px root font sizes also matched on every computed property of every element and pseudo-element.
That comparison covered 117804 elements and pseudo-elements in the rendered state.
It covered 368604 more after marking controls invalid, disabled, checked and open and adding synthetic markup for every form control class in content, dialog, sign-in card and Astryx root contexts.
It covered the focus-visible state of the first control of each kind, 1100 snapshots in all.
