Artium form controls extraction, 100 before-and-after screenshot pairs.

Baseline: e8ea8b5aa7ad05924025f1e85b0ced0960facc6d
Baseline CSS SHA-256: 1beb683957131b5cf29f5753f670def33cd81f36c39526acb2f8309891442a11
Original extraction CSS SHA-256: fdbc50945ab1c35600d04a05eff996b9262d3580d39fa9247279eba8a5a5061e
Final extraction CSS SHA-256: b2c777ec7fe38be352be36e14027f440d3d6f26de410f52844b20bc430b4863a

Final extraction captures

The 30 pairs for users, audit, invitations, tool-add, ssh, provider-entra, provider-oidc, provider-rules, device, and login compare the baseline with the final stylesheet.
The pairs use the same local fixture and Chrome 154.0.8037.57 on both sides, with baseline CSS substituted for /admin/assets/style.css on the before side.
The users, audit, invitations, tool-add, and ssh forms cover five light, dark, and system-dark combinations at 1280 by 900 and 390 by 844, with reduced motion, a 16px root font size, and synthetic field values.
The provider, role rule, and device forms use the same desktop light setting.
The checked TextInputs use the baseline monospace font, and the SSH TextAreas preserve their baseline font.
The rendered unauthenticated /login form is captured at 1280 by 900 in light mode, and its two TextInput border overrides match the field border token on both sides.
All 30 final pairs are byte-identical PNG files.

Original extraction captures and computed styles

Both sides use the same synthetic fixture and Chromium session.
Before replaces the page stylesheet with the baseline token, component and frame CSS.
After replaces it with the stylesheet served by the original extraction.
The archive retains 70 byte-identical PNG pairs from this run.
The original run covered 19 pages, the light, dark and system dark themes, and 1280px and 390px viewports.
It included an open confirmation dialog and an open add-instance sheet.

The same 190 cases at the default and 20px root font sizes also matched on every computed property of every element and pseudo-element.
That comparison covered 117804 elements and pseudo-elements in the rendered state.
It covered 368604 more after marking controls invalid, disabled, checked and open and adding synthetic markup for every form control class in content, dialog, sign-in card and Astryx root contexts.
It covered the focus-visible state of the first control of each kind, 1100 snapshots in all.
