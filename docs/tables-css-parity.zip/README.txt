Artium table styles extraction, 82 before-and-after screenshot pairs.

Baseline revision: e769a8670036ace6dfa66fb0973a0ad0ac2bff38
Baseline CSS SHA-256: 7237f59616e041bf21591eb2296d8df0c582f25729e181dd118bbbdf28ba12ba
Candidate CSS SHA-256: 24e0fca2c7604310c9348dfad6e560a69d4cbb3403a6ee5010c2c95745bf12d1

The baseline stylesheet is tokens, components, frame and forms, served as /admin/assets/style.css.
The candidate stylesheet adds tables.css after forms.css, with every table rule moved out of components.ts in its original relative order.
It also moves the .filters margin reset from components.ts into the .filters rule in forms.css.

Screenshots

Both sides use the same synthetic fixture (test/fake-service/browser-auth.mjs) and Chrome 154.0.8037.57 with a 1x device scale factor.
Before is the build of the baseline revision and after is the build of the candidate.
The fixture seeds 103 audit records, one SSH execution and the default users, roles and tools.
Time-dependent text is set to a fixed string on both sides before capture: the recent-authentication countdown and every time element.
The 13 pages are overview, users, person, roles, role, tools, tool (Instances tab), instance, invitations, signin, tokens, audit and account.
They are captured in light, dark and system dark themes at 1280 by 800 and 390 by 844.
The users and audit pages are also captured with keyboard focus on the first row link, and with the pointer over a row.
All pairs are byte-identical PNG files.
The captures at 900 by 800 were also compared and are byte-identical, but are not retained here.
In all, 225 screenshot pairs matched, including 104 pairs of a synthetic page that are not retained here.

Tables rendered with rows by the fixture are People, the person page tools table, Roles, role members, the Tools list, the Instances tab, the audit log and the account sessions.
The Invitations, Sign-in providers, role rules, access tokens, SSH events and trusted certificates tables have no rows in the fixture.
Their styles are covered by the synthetic page below.

Computed styles

178 page states were dumped on each side: the 13 pages in light and dark themes at 1280, 900 and 390 widths, at the default and 20px root font sizes, plus the focus and hover states and the synthetic page.
The synthetic page appends a copy of an Astryx table for each wrapper class (people, roles, tools, instances, invitations, providers, rules, tokens, audit, SSH events, sessions, plain and link rows) at 1100, 800 and 600px wide.
Its cells carry every data-label, cell class, row class and cell content the table rules select, and it adds a plain table and a dialog table outside the Astryx root.
All 162 selectors in tables.css match an element on it.
Each dump hashes the sorted computed property list of every element, with ::before, ::after and ::marker where they generate content.
Across the 178 dumps, 427718 elements matched between baseline and candidate.
Two baseline runs of the 13 pages in light at 1280 matched each other (32 dumps, 55850 elements, 43 screenshots), and a deliberate font weight change in tables.css was detected by the same comparison.
