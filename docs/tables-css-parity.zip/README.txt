Artium table styles extraction, 106 before-and-after screenshot pairs.

Of the 106 retained pairs, 103 are identical both as PNG files and as decoded RGBA pixels.
The three 1280px Account pairs differ only in the synthetic localhost port shown in the CLI setup command.

Baseline revision: e769a8670036ace6dfa66fb0973a0ad0ac2bff38
Baseline CSS SHA-256: 7237f59616e041bf21591eb2296d8df0c582f25729e181dd118bbbdf28ba12ba
Candidate CSS SHA-256: 24e0fca2c7604310c9348dfad6e560a69d4cbb3403a6ee5010c2c95745bf12d1

The baseline stylesheet is tokens, components, frame and forms, served as /admin/assets/style.css.
The candidate stylesheet adds tables.css after forms.css, with every table rule moved out of components.ts in its original relative order.
It also moves the .filters margin reset from components.ts into the .filters rule in forms.css.

Page screenshots

Both sides use the same synthetic fixture (test/fake-service/browser-auth.mjs) and Chrome 154.0.8037.57 with a 1x device scale factor.
Before is the build of the baseline revision and after is the build of the candidate.
The fixture seeds 103 audit records, one SSH execution and the default users, roles and tools.
Time-dependent text is set to a fixed string on both sides before capture: the recent-authentication countdown and every time element.
The 13 pages are overview, users, person, roles, role, tools, tool (Instances tab), instance, invitations, signin, tokens, audit and account.
They are captured in light, dark and system dark themes at 1280 by 800 and 390 by 844, giving 78 pairs.
The users and audit pages are also captured with keyboard focus on the first row link, and with the pointer over a row, giving 4 more pairs.
The captures at 900 by 800 were also compared and are byte-identical, but are not retained here.

Populated table screenshots (files named *-populated-*)

The fixture has no rows for the invitations, sign-in providers, role rules, access tokens, SSH events and trusted certificates tables.
For these six, the harness opens the real page (Invitations, Sign-in and SSO twice, Access tokens, SSH audit and the Falcon instance page) and appends a populated table below the page content.
The appended table is a copy of the rendered People table, rebuilt with that table's wrapper class, its columns and realistic rows, and with the cell classes, data-label attributes and cell content (buttons, badges, chips, code, token scope lists and event details) that the views use.
The appended section is not part of the page layout, so it sits outside the page padding.
Each state is captured in light and dark themes at 1280 by 800 and 390 by 844, giving 24 pairs.
The 390 pixel captures show the stacked narrow layouts.
The before side for these 24 pairs is a build of the baseline revision made in a separate source tree.

Computed styles

These checks support the screenshots and are not a substitute for them.
178 page states were dumped on each side: the 13 pages in light and dark themes at 1280, 900 and 390 widths, at the default and 20px root font sizes, plus the focus and hover states and a synthetic page.
The synthetic page appends a copy of an Astryx table for each wrapper class (people, roles, tools, instances, invitations, providers, rules, tokens, audit, SSH events, sessions, plain and link rows) at 1100, 800 and 600px wide.
Its cells carry every data-label, cell class, row class and cell content the table rules select, and it adds a plain table and a dialog table outside the Astryx root.
All 162 selectors in tables.css match an element on it.
Screenshots of the synthetic page matched too, but are not retained here.
Each dump hashes the sorted computed property list of every element, with ::before, ::after and ::marker where they generate content.
Across the 178 dumps, 427718 elements matched between baseline and candidate.
Two baseline runs of the 13 pages in light at 1280 matched each other (32 dumps, 55850 elements, 43 screenshots), and a deliberate font weight change in tables.css was detected by the same comparison.
