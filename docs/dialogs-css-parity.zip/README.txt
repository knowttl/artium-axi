Artium dialog and auth CSS parity, 80 before-and-after screenshot pairs.

All pairs are byte-identical PNGs.
Every pair is also checked by comparing the computed style and layout rectangle of every element, including its ::before, ::after and dialog ::backdrop styles, at the default and 20px root font sizes.
Those comparisons found no differences in any of the 80 captures.

Baseline revision: cd1e23edd58669fe899482b1139845de6f1ef16f
Baseline CSS SHA-256: 69820b8f07f1992cf15c658043248d57fdbd761946e86ec5080b138596a098b6
Original candidate CSS SHA-256: 1acc02fba0c5af6271538bec5fcc371d016349a9d7873e54918a0db089e90f9c
Supplemental candidate CSS SHA-256: 85c206b865abbfdcc59671f0c5ffe31615ab7065f97ed559e880c5271c65a054
Browser: Google Chrome 154.0.8037.57, headless, with software rendering and deterministic compositing

Original capture method

The local browser fixture ran the compiled server with a synthetic administrator, a disabled synthetic Entra provider, a synthetic Vectra instance and seeded audit records.
Each state was captured in light and dark at 1280 by 800 and 390 by 844.
The before capture loads the page with the baseline stylesheet served at /admin/assets/style.css.
The after capture loads the same page with the candidate stylesheet.
The new role error, access token and certificate inspection states change server data when they are reached.
For those three states the page is loaded once and the baseline stylesheet is swapped in at the original cascade position for the before capture.
Caret blinking, request ID text and the recent-authentication minute counter are normalized in both captures.
The resolved values of the Astryx tokens used by dialogs.css are identical to the legacy values they replace in both themes and at both root font sizes: --spacing-0 is 0, --border-width is 1px and --font-weight-semibold is 600.
Surface, text, border and status colors, font sizes, corner radii, nonzero spacing, layout dimensions, z-index values and the 760px breakpoint keep their legacy values, because the Astryx values differ or scale with the root font size.

Original capture set (68 pairs)

login-provider (4): Signed-out sign-in with the provider button, password field and footer.
login-provider-help (4): The same page with the Need help? disclosure open.
login (4): Signed-out sign-in with the password form only.
login-failed (2): Sign-in after an unknown username, showing the request failure block (light 1280 and dark 390 only, to stay under the sign-in attempt limit).
password-forced (4): Forced password change with the signed-in footnote, sign-out button, theme switch and help disclosure.
device-code (4): CLI approval code entry.
reauth-page (4): Confirm password page with the neutral lock icon circle.
reauth-page-ok-mark-simulated (4): Simulated: the same page with the lock icon circle switched to the ok tone.
reauth-page-warn-mark-simulated (4): Simulated: the same page with the lock icon circle switched to the warn tone.
invitation-sheet (4): New invitation side sheet with a synthetic provider, roles and expiry field.
new-role-sheet (4): New role side sheet.
new-role-sheet-message (4): New role side sheet after a duplicate name, showing the form error box and error toast.
audit-record-sheet (4): Docked audit record sheet with its header close button.
tool-confirmation (4): Confirmation dialog for enabling a tool.
created-token-dialog (4): One-time access token dialog opened over the account page.
certificate-inspection (4): Certificate inspection dialog with the fingerprint warning, details and Close button.
reauth-dialog (4): In-page Confirm it’s you dialog over the New role sheet.
reauth-dialog-error (2): The same dialog after a wrong password (light 1280 and dark 390 only, to stay under the sign-in attempt limit).

Supplemental capture set (12 pairs)

The supplemental pairs use the same baseline and the stylesheet after the unused certificate panel and sheet header button selectors were removed.
Each state was captured in light and dark at 1280 by 800 and 390 by 844.
The server-open sheet and SSO page received the baseline directly at /admin/assets/style.css.
For certificate inspection, the same open dialog was used across configurations and the baseline was swapped into the original cascade position.

new-role-sheet-before-hydration (4): Server-open New role sheet with its scrim displayed. The browser blocked the hydration bundle. On mobile the full-width sheet covers the scrim.
certificate-inspection-name-change (4): Certificate inspection for a synthetic IP endpoint whose certificate names localhost. The dialog is scrolled to show the real name-change button, whose label wraps at 390px.
reauth-page-sso-sign-out (4): Confirm identity page after sign-in through the synthetic SSO provider, showing the unchecked provider sign-out checkbox.

Files

dark-1280-audit-record-sheet.png
dark-1280-certificate-inspection-name-change.png
dark-1280-certificate-inspection.png
dark-1280-created-token-dialog.png
dark-1280-device-code.png
dark-1280-invitation-sheet.png
dark-1280-login-provider-help.png
dark-1280-login-provider.png
dark-1280-login.png
dark-1280-new-role-sheet-before-hydration.png
dark-1280-new-role-sheet-message.png
dark-1280-new-role-sheet.png
dark-1280-password-forced.png
dark-1280-reauth-dialog.png
dark-1280-reauth-page-ok-mark-simulated.png
dark-1280-reauth-page-sso-sign-out.png
dark-1280-reauth-page-warn-mark-simulated.png
dark-1280-reauth-page.png
dark-1280-tool-confirmation.png
dark-390-audit-record-sheet.png
dark-390-certificate-inspection-name-change.png
dark-390-certificate-inspection.png
dark-390-created-token-dialog.png
dark-390-device-code.png
dark-390-invitation-sheet.png
dark-390-login-failed.png
dark-390-login-provider-help.png
dark-390-login-provider.png
dark-390-login.png
dark-390-new-role-sheet-before-hydration.png
dark-390-new-role-sheet-message.png
dark-390-new-role-sheet.png
dark-390-password-forced.png
dark-390-reauth-dialog-error.png
dark-390-reauth-dialog.png
dark-390-reauth-page-ok-mark-simulated.png
dark-390-reauth-page-sso-sign-out.png
dark-390-reauth-page-warn-mark-simulated.png
dark-390-reauth-page.png
dark-390-tool-confirmation.png
light-1280-audit-record-sheet.png
light-1280-certificate-inspection-name-change.png
light-1280-certificate-inspection.png
light-1280-created-token-dialog.png
light-1280-device-code.png
light-1280-invitation-sheet.png
light-1280-login-failed.png
light-1280-login-provider-help.png
light-1280-login-provider.png
light-1280-login.png
light-1280-new-role-sheet-before-hydration.png
light-1280-new-role-sheet-message.png
light-1280-new-role-sheet.png
light-1280-password-forced.png
light-1280-reauth-dialog-error.png
light-1280-reauth-dialog.png
light-1280-reauth-page-ok-mark-simulated.png
light-1280-reauth-page-sso-sign-out.png
light-1280-reauth-page-warn-mark-simulated.png
light-1280-reauth-page.png
light-1280-tool-confirmation.png
light-390-audit-record-sheet.png
light-390-certificate-inspection-name-change.png
light-390-certificate-inspection.png
light-390-created-token-dialog.png
light-390-device-code.png
light-390-invitation-sheet.png
light-390-login-provider-help.png
light-390-login-provider.png
light-390-login.png
light-390-new-role-sheet-before-hydration.png
light-390-new-role-sheet-message.png
light-390-new-role-sheet.png
light-390-password-forced.png
light-390-reauth-dialog.png
light-390-reauth-page-ok-mark-simulated.png
light-390-reauth-page-sso-sign-out.png
light-390-reauth-page-warn-mark-simulated.png
light-390-reauth-page.png
light-390-tool-confirmation.png
